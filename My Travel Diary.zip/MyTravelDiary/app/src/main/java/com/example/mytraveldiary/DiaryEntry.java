package com.example.mytraveldiary;

public class DiaryEntry {
    private String imageUrl;
    private double latitude;
    private double longitude;
    private String date;

    public DiaryEntry(String imageUrl, double latitude, double longitude, String date) {
        this.imageUrl = imageUrl;
        this.latitude = latitude;
        this.longitude = longitude;
        this.date = date;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public double getLatitude() {
        return latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public String getDate() {
        return date;
    }
}
