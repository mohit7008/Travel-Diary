package com.example.mytraveldiary;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.annotation.Nullable;

public class DiaryListActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private DiaryAdapter adapter;
    private final List<DiaryEntry> diaryEntries = new ArrayList<>();

    private final FirebaseFirestore firestore = FirebaseFirestore.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diary_list);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new DiaryAdapter(diaryEntries, this);
        recyclerView.setAdapter(adapter);

        // Pehle local entry add karo
       // loadFromSharedPreferences();

        // Firestore realtime listener lagao
        listenToFirestore();
    }

    private void loadFromSharedPreferences() {
        SharedPreferences prefs = getSharedPreferences("DiaryData", MODE_PRIVATE);

        String imageUrl = prefs.getString("imageUrl", null);
        String lat = prefs.getString("latitude", null);
        String lng = prefs.getString("longitude", null);
        String timestamp = prefs.getString("timestamp", null);

        if (imageUrl != null && lat != null && lng != null && timestamp != null) {
            String formattedDate = new SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
                    .format(new Date(Long.parseLong(timestamp)));

            DiaryEntry entry = new DiaryEntry(
                    imageUrl,
                    Double.parseDouble(lat),
                    Double.parseDouble(lng),
                    formattedDate
            );

            diaryEntries.add(0, entry); // local entry sabse upar
            adapter.notifyDataSetChanged();
        }
    }

    private void listenToFirestore() {
        firestore.collection("DiaryEntries")
                .addSnapshotListener(new EventListener<QuerySnapshot>() {
                    @Override
                    public void onEvent(@Nullable QuerySnapshot snapshots,
                                        @Nullable FirebaseFirestoreException e) {
                        if (e != null) {
                            Toast.makeText(DiaryListActivity.this,
                                    "Error: " + e.getMessage(),
                                    Toast.LENGTH_SHORT).show();
                            return;
                        }

                        if (snapshots != null) {
                            // Pehle Firestore wali old entries clear karo (par SharedPref wali nahi)
                            if (diaryEntries.size() > 0 && diaryEntries.get(0).getLatitude() != 0) {
                                // pehla wala SharedPref entry ko chhod ke sab clear karo
                                DiaryEntry localEntry = diaryEntries.get(0);
                                diaryEntries.clear();
                                diaryEntries.add(localEntry);
                            } else {
                                diaryEntries.clear();
                            }

                            for (DocumentSnapshot doc : snapshots.getDocuments()) {
                                String imageUrl = doc.getString("imageUrl");
                                Double latitude = doc.getDouble("latitude");
                                Double longitude = doc.getDouble("longitude");
                                String timestamp = doc.getString("timestamp");

                                if (imageUrl != null && latitude != null && longitude != null && timestamp != null) {
                                    String formattedDate = new SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
                                            .format(new Date(Long.parseLong(timestamp)));

                                    DiaryEntry entry = new DiaryEntry(
                                            imageUrl,
                                            latitude,
                                            longitude,
                                            formattedDate
                                    );

                                    diaryEntries.add(entry);
                                }
                            }

                            adapter.notifyDataSetChanged();
                        }
                    }
                });
    }
}
