package com.example.mytraveldiary;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.mytraveldiary.R;

import java.util.List;

public class DiaryAdapter extends RecyclerView.Adapter<DiaryAdapter.ViewHolder> {

    private final List<DiaryEntry> diaryList;
    private final Context context;

    public DiaryAdapter(List<DiaryEntry> diaryList, Context context) {
        this.diaryList = diaryList;
        this.context = context;
    }

    @NonNull
    @Override
    public DiaryAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_diary_entry, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DiaryAdapter.ViewHolder holder, int position) {
        DiaryEntry entry = diaryList.get(position);

        holder.txtDate.setText(entry.getDate());
        holder.txtLocation.setText("Lat: " + entry.getLatitude() + ", Lng: " + entry.getLongitude());

        Glide.with(context)
                .load(entry.getImageUrl())
                .into(holder.imgDiary);
    }

    @Override
    public int getItemCount() {
        return diaryList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imgDiary;
        TextView txtDate, txtLocation;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imgDiary = itemView.findViewById(R.id.diaryImage);
            txtDate = itemView.findViewById(R.id.diaryTime);
            txtLocation = itemView.findViewById(R.id.diaryLocation);
        }
    }
}
