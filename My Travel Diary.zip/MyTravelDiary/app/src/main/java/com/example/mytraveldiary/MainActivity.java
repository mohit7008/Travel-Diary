package com.example.mytraveldiary;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import com.example.mytraveldiary.utils.LocationUtils;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private Button btnCapture, btnPick, btnDiary;
    private ImageView previewImage;
    private TextView txtLastSaved;
    private ProgressBar progressBar;

    private Uri selectedImage;

    private final FirebaseStorage storage = FirebaseStorage.getInstance();
    private final FirebaseFirestore firestore = FirebaseFirestore.getInstance();

    private SharedPreferences sharedPreferences;

    // Permission launcher
    private final ActivityResultLauncher<String[]> permissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), result -> {
                if (!Boolean.TRUE.equals(result.get(Manifest.permission.CAMERA)) ||
                        !Boolean.TRUE.equals(result.get(Manifest.permission.ACCESS_FINE_LOCATION))) {
                    Toast.makeText(this, "Permissions required!", Toast.LENGTH_SHORT).show();
                }
            });

    // Camera launcher
    private final ActivityResultLauncher<Intent> cameraLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    Bundle extras = result.getData().getExtras();
                    if (extras != null) {
                        Bitmap bitmap = (Bitmap) extras.get("data");
                        if (bitmap != null) {
                            previewImage.setImageBitmap(bitmap);

                            // Save captured image locally
                            saveCaptureImage(bitmap);

                            try {
                                File file = new File(getCacheDir(), "camera_photo.jpg");
                                FileOutputStream out = new FileOutputStream(file);
                                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, out);
                                out.flush();
                                out.close();

                                selectedImage = FileProvider.getUriForFile(
                                        this,
                                        getPackageName() + ".provider",
                                        file
                                );

                            } catch (Exception e) {
                                Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    }
                }
            });

    // Gallery launcher
    private final ActivityResultLauncher<String> galleryLauncher =
            registerForActivityResult(new ActivityResultContracts.GetContent(), uri -> {
                if (uri != null) {
                    selectedImage = uri;
                    previewImage.setImageURI(uri);
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnCapture = findViewById(R.id.btnCapture);
        btnPick = findViewById(R.id.btnPick);
        btnDiary = findViewById(R.id.btnDiary);
        previewImage = findViewById(R.id.previewImage);
        txtLastSaved = findViewById(R.id.txtLastSaved);
        progressBar = findViewById(R.id.progressBar);

        sharedPreferences = getSharedPreferences("DiaryData", MODE_PRIVATE);

        // Ask permissions
        permissionLauncher.launch(new String[]{
                Manifest.permission.CAMERA,
                Manifest.permission.ACCESS_FINE_LOCATION
        });

        btnCapture.setOnClickListener(v -> {
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            cameraLauncher.launch(intent);
        });

        btnPick.setOnClickListener(v -> galleryLauncher.launch("image/*"));

        btnDiary.setOnClickListener(v -> {
            // Open DiaryListActivity
            startActivity(new Intent(this, DiaryListActivity.class));
        });
    }

    // New method to save image URL + location in Firestore
    private void saveImageDataToFirestore() {
        if (selectedImage == null) {
            Toast.makeText(this, "Please select or capture an image first", Toast.LENGTH_SHORT).show();
            return;
        }

        progressBar.setVisibility(ProgressBar.VISIBLE);

        LocationUtils.getCurrentLocation(this, (lat, lng) -> {
            String fileName = "images/" + System.currentTimeMillis() + ".jpg";
            StorageReference ref = storage.getReference().child(fileName);

            ref.putFile(selectedImage).addOnSuccessListener(task -> {
                ref.getDownloadUrl().addOnSuccessListener(uri -> {
                    saveFirestoreEntry(uri.toString(), lat, lng);
                }).addOnFailureListener(e -> {
                    progressBar.setVisibility(ProgressBar.GONE);
                    Toast.makeText(this, "Failed to get download URL: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
            }).addOnFailureListener(e -> {
                progressBar.setVisibility(ProgressBar.GONE);
                Toast.makeText(this, "Upload failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            });
        });
    }

    // Method in the style of savedataoffirestore()
    private void saveFirestoreEntry(String imageUrl, double latitude, double longitude) {
        String timestamp = String.valueOf(System.currentTimeMillis());

        Map<String, Object> data = new HashMap<>();
        data.put("imageUrl", imageUrl);
        data.put("latitude", latitude);
        data.put("longitude", longitude);
        data.put("timestamp", timestamp);

        firestore.collection("DiaryEntries")
                .add(data)
                .addOnSuccessListener(doc -> {
                    progressBar.setVisibility(ProgressBar.GONE);
                    txtLastSaved.setText("Last saved");

                    // ✅ Save to SharedPreferences
                    saveDataToSharedPreferences(imageUrl, latitude, longitude, timestamp);

                    Toast.makeText(this, "Saved to Firestore & Local", Toast.LENGTH_SHORT).show();
                    selectedImage = null;
                })
                .addOnFailureListener(e -> {
                    progressBar.setVisibility(ProgressBar.GONE);
                    Toast.makeText(this, "Firestore error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }

    private void saveDataToSharedPreferences(String imageUrl, double latitude, double longitude, String timestamp) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("imageUrl", imageUrl);
        editor.putString("latitude", String.valueOf(latitude));
        editor.putString("longitude", String.valueOf(longitude));
        editor.putString("timestamp", timestamp);
        editor.apply();
    }

    // Save captured image to device gallery
    private void saveCaptureImage(Bitmap bitmap){
        try {
            ContentValues images = new ContentValues();
            images.put(MediaStore.Images.Media.DISPLAY_NAME, "ISHA_" + System.currentTimeMillis() + ".jpg");
            images.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            images.put(MediaStore.Images.Media.RELATIVE_PATH, "DCIM/Camera");

            Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, images);
            if (uri != null){
                OutputStream outputStream = getContentResolver().openOutputStream(uri);
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream);
                if (outputStream != null){
                    outputStream.close();
                }

                Toast.makeText(this, "Image saved successfully", Toast.LENGTH_SHORT).show();

                // ✅ Firestore me URI + location save karna
                saveGalleryUriWithLocation(uri);

            } else {
                Toast.makeText(this,"Failed to save image",Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e){
            e.printStackTrace();
            Toast.makeText(this, "Error saving image", Toast.LENGTH_SHORT).show();
        }
    }

    // Yeh naya method add karein
    @SuppressLint("MissingPermission")
    private void saveGalleryUriWithLocation(Uri uri) {
        if (uri == null) {
            Toast.makeText(this, "Image URI not found!", Toast.LENGTH_SHORT).show();
            return;
        }

        FusedLocationProviderClient client = LocationServices.getFusedLocationProviderClient(this);

        client.getLastLocation().addOnSuccessListener(location -> {
            if (location != null) {
                double lat = location.getLatitude();
                double lng = location.getLongitude();

                Toast.makeText(this, "Got Location: " + lat + ", " + lng, Toast.LENGTH_SHORT).show();

                String timestamp = String.valueOf(System.currentTimeMillis());

                Map<String, Object> data = new HashMap<>();
                data.put("imageUrl", uri.toString());
                data.put("latitude", lat);
                data.put("longitude", lng);
                data.put("timestamp", timestamp);

                firestore.collection("DiaryEntries")
                        .add(data)
                        .addOnSuccessListener(doc -> {
                            saveDataToSharedPreferences(uri.toString(), lat, lng, timestamp);
                            Toast.makeText(this, "Firestore Save Success", Toast.LENGTH_SHORT).show();
                        })
                        .addOnFailureListener(e -> {
                            Toast.makeText(this, "Firestore Save Failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
                        });

            } else {
                Toast.makeText(this, "Location not available", Toast.LENGTH_SHORT).show();
            }
        }).addOnFailureListener(e -> {
            Toast.makeText(this, "Location fetch failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
        });
    }
}
