// LocationUtils.java
package com.example.mytraveldiary.utils;

import android.annotation.SuppressLint;
import android.content.Context;
import android.location.Location;
import android.os.Looper;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;

public class LocationUtils {

    public interface LocationCallbackListener {
        void onLocationResult(double lat, double lng);
    }

    @SuppressLint("MissingPermission")
    public static void getCurrentLocation(Context context, LocationCallbackListener callback) {
        FusedLocationProviderClient client = LocationServices.getFusedLocationProviderClient(context);

        // Request high accuracy updates
        LocationRequest locationRequest = LocationRequest.create()
                .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
                .setInterval(2000)   // 2 sec interval
                .setFastestInterval(1000) // 1 sec
                .setNumUpdates(1);  // Sirf 1 baar location chahiye

        client.requestLocationUpdates(locationRequest, new LocationCallback() {
            @Override
            public void onLocationResult(LocationResult locationResult) {
                client.removeLocationUpdates(this); // Stop after first result
                if (locationResult != null && !locationResult.getLocations().isEmpty()) {
                    Location location = locationResult.getLastLocation();
                    if (location != null) {
                        callback.onLocationResult(location.getLatitude(), location.getLongitude());
                        return;
                    }
                }
                // Agar null mil jaye to fallback 0 bhejo
                callback.onLocationResult(0, 0);
            }
        }, Looper.getMainLooper());
    }
}
